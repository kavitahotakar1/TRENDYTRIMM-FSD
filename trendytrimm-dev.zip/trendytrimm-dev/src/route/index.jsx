import React from "react";
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from "../component/Home";
import Navbar from "../component/Navbar";
import Footer from "../component/Footer";
import Categories from '../component/Categories';
import Cart from '../component/Cart';
import Loginform from "../component/Loginform";
import Forgot from "../component/Forgot";
import Women from "../component/Women";
import Men from "../component/Men";
import Kids from "../component/Kids";
import Contact from "../component/Conatct";
import Product from "../component/Product";
import CheckoutPage from "../component/Checkoutpage";
import PaymentDetailsPage from "../component/PaymentDetailsPage";
import About from "../component/About";



const AppRoute = _ => (
  <Router>
    <Navbar />
    
    <Routes>

      <Route path="/" element={<Home />} />
      <Route path="/categories" element={<Categories />} />
      <Route path="/Contact" element={<Contact />} />
      <Route path="/Loginform" element={<Loginform />} />
      <Route path="/Forgot" element={<Forgot />} />
      <Route path="/Women" element={<Women />} />
      <Route path="/Men" element={<Men />} />
      <Route path="/Kids" element={<Kids />} />
      <Route path="/Checkoutpage" element={<CheckoutPage />} />
      <Route path="/Cart" element={<Cart />} />
      <Route path="/Product" element={<Product />} />
      <Route path="/About" element={<About />} />
      
      <Route path="PaymentDetailsPage" element={<PaymentDetailsPage />} />
      
    </Routes><br />

    <Footer />
    
    
  </Router>

);
export default AppRoute;