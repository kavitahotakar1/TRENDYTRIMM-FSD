import React from "react";
import { Row, Col} from "antd";
import '../css/About.css';
import about from '../assest/images/about.webp';




const About = () => {
    return(
      <>
      

        <div className="shop">
        <h1 className="shop1">About Us</h1>
        <p id="shop2">Everyday Fashion is our promise to you</p>
            <Row>
               
                <Col>
               
              
                <p id="shop3">If there's one thing we know about our customers-they're busy living.
                They're going to work.They're raising kids.
                They're hitting the gym.They're studing for tests.They're headed out on friday night.
                They're staying in with Sunday pancakes.
                Keeping you effortlessly stylish throughout the day lies at the core of what we do.
                At Clothing Shop Online,we've made it our mission to provide simple,
                affordable wardrobe staples to people who love to live.
                we've got the looks you want,from the brands you love,in the colors and sizes you need.
                Skip the lines at the mall: we've created an online shopping experience that fits
                 your schedule just as well as it does your budget.Within minutes,
                 you can stock up on the leading brands you love to wear every day.
                 Imagine Gildan,Bella+Canvas,and Hanes,right at your fingertips.
                 Our intuitive shopping experience was designed to help you quickly find your favs,
                 while discovering new ones along the way.At Clothing Shop Online,
                 we want you to be comfortable,confident,
                 and carefree - In what you wear and how you shop.Let us dress your every day. </p>
                </Col>
            </Row>
            
            </div>

           
</>

    )
};

export default About;