// Cart.js
import React from "react";
import "../css/Cart.css";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { useDispatch } from 'react-redux';
import cart1 from "../assest/images/Empty1.png"
import { Row, Col } from "antd";
import { Alert } from "antd";
import { removeFromCart } from "./redux/Action";
import toast from 'react-hot-toast';

const Cart = () => {
  const dispatch = useDispatch();
  const cart = useSelector(state => state.cart);
  const handleRemoveFromCart = (item) => {
    dispatch(removeFromCart(item));
    toast.success("Item removed from cart")
  };
  

  const cartItems = useSelector((state) => state.cart);
  const subtotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const salesRate = 0.1; // You can adjust the tax rate as needed
  const salesdisRate = subtotal * salesRate;
  const total = subtotal - salesdisRate;

  return (
    <div className="cart-page">
      <h2 id="C1"> Shopping Cart</h2><br />
      {cartItems.length === 0 ?(
        <div>
          <img src={cart1} id="Cart1" />
        </div>) :
        (
          <ul>
            {cartItems.map((item, index) => (
              <li key={index}>
                <Row>
                  <Col md={12}>
                    <Row className="Main">
                      <Col gutter={12} md={6} >
                        <div>
                          <img src={item.image} alt={item.name} height={'100px'} width={'100px'} id="TP" />
                        </div>
                      </Col>
                      <Col gutter={12} md={12}>
                        <div>
                          <h3 id="I3">{item.name}</h3>
                          <p>${item.price}</p>
                          <p id="PP">Quantity {item.quantity}</p>
                          <span className='SSS'>Free Delivery</span>
                        </div>
                      </Col>
                      <Col >
                        <button className="REmove" onClick={() => handleRemoveFromCart(item.id)}>Remove</button>
                      </Col>
                    </Row>

                  </Col>
                  
                  {/* <Col className="toT">
            
                    <div className="TOTALL">
                      <p id="PD">Price Details </p>
                      <p id="TOTALL" >Total Product Price:  + ₹{subtotal}</p>
                      <p id="TOTALL1">Total Discounts:   - ₹{salesdisRate}</p><hr />
                      <p id="TOTALL2">Order Total:     ₹{total}</p><br />
                      <Alert message=" Yay!  Discount  Price  " type="success" className="XXX" />
                    </div>
                  </Col> */}
                </Row>
                {/* <Row>
                  <Col>
                    <div className="BC">
                      <Link to="/Checkoutpage" className="BB">Continue </Link></div></Col>
                </Row> */}

              </li>
            ))}
          </ul>
        )}
        <div className="ddd">
        <Col className="toT">
            
            <div className="TOTALL">
              <p id="PD">Price Details </p>
              <p id="TOTALL" >Total Product Price:  + ₹{subtotal}</p>
              <p id="TOTALL1">Total Discounts:   - ₹{salesdisRate}</p><hr />
              <p id="TOTALL2">Order Total:     ₹{total}</p><br id="BBR"/>
              <Alert message=" Yay!  Discount  Price  " type="success" className="XXX" />
              
                    <div className="BC">
                      <Link to="/Checkoutpage" className="BB">Continue </Link></div>
               
            </div>
          </Col>
         
          </div>

      <br />
    </div>

  );

};


export default Cart;
