import React from "react";
import "../css/Contact.css";
import { Row, Col } from "antd";
import {  message } from 'antd';
import background1 from "../assest/images/background1.jpg";

import {MailOutlined, PhoneOutlined ,EnvironmentOutlined  } from "@ant-design/icons";

const Contact = () => {

    const [messageApi, contextHolder] = message.useMessage();
        const key = 'updatable';
      
        const openMessage = () => {
          messageApi.open({
            key,
            type: 'loading',
            content: 'Loading...',
          });
          setTimeout(() => {
            messageApi.open({
              key,
              type: 'success',
              content: 'Submit Sucessfully!',
              duration: 2,
            });
          }, 1000);
        };
   
    return(
        <div >
            <div className="C">
           
            
            <Row > 
              <Row>
           
                <Col>
               
                <h1 id="CU">Contact Us</h1>
                <div className="Contact">
                <img src={background1} alt="fds" height={'400px'} width={'700px'} />
              <div className="Contact1">
              <h1 id="call">
              <PhoneOutlined />
                 <h3 id="call1">34253642432</h3></h1><br/><br />

                <h1 id="call">
                <MailOutlined />
                 <h3 id="call1"> trendytrimm@6gmail.com</h3></h1><br /><br />


                 <h1 id="CALL">
                <EnvironmentOutlined />
                 <h3 id="call3"> arlig technology near<br/>takke road tregry colony<br/>vijayapur</h3></h1><br /><br />
              </div>
              </div>
                </Col>
            </Row>
            <Col>
            <div className="second-part">
            <div className="get-in">
            <h6 className="head">Use the form below to get in touch with us.</h6>
            
            <div className="Contact-box">
                    <input type="text" id="BBox" placeholder='Enter Your Name' required/><br /><br />
                    <input type="text" id="BBox" placeholder="Enter Your Phone Number" required/> <br /><br />
                    <input type="text" id="BBox" placeholder="Enter Your Email" required/><br /><br />
                    <input type="text" id="BBox" placeholder="Enter Your Message" required/><br /><br />
                    <input type="text" id="BBox" placeholder="Enter Your Address" required/><br /><br />
                    <center>   {contextHolder}<button type="primary" onClick={openMessage} id="Submit"> Submit </button></center>

            </div>
        </div>
        </div><br /></Col>
            </Row></div>

           

        </div>
       
    )
}

export default Contact;