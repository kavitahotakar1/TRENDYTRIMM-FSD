import React from 'react'
import { useDispatch } from 'react-redux';
import '../css/Categories.css';
import { addToCart } from './redux/Action';
import Kidsadata from '../data/Kidsdata';
import { toast } from 'react-hot-toast';

const Categories = () => {
  const dispatch=useDispatch()
  const handleAddToCart = (item) => {
      // Dispatch the addToCart action with the item as payload
      dispatch(addToCart(item));
      toast.success("Item added to your cart")
    };

    
  return (
    <div>
      <br /><br /><br /><br />
           
    <div className="BUU"><hr id="Hi" />
    <div className='Button-Box'>
      <a href="/categories" className="Btn  ms-4">
      All
      </a>
      </div>
      <div className='Button-Box'>
      <a href="/Women" className="Btn  ms-4">
      Women's
      </a>
      </div>
      <div className='Button-Box'>
      <a href="/Men" className="Btn  ms-4">
     Men's
      </a>
      </div>
      <div className='Button-Box'>
      <a href="Kids" className="Btn  ms-4">
     Kid's
      </a>
      </div><hr id="Hi" /></div>

    <div className='categories'>
      {Kidsadata.map((item, index) => (
      <div className="cat-cont" key={index}>
        <img src={item.image} alt="" className='cat-cont-img' />
        <span className='cat-cont-title'>{item.name}</span><br />
        <span className='rating'>{item.star}⭐</span><br />
        <span className="cat-cont-price"> {item.price} <s>{item.mrp}</s></span><br />
        <span className='free-delivery'>Free Delivery</span><br />
       
        <button className='cart-btn' onClick={() => handleAddToCart(item)}>Add to Cart</button>
      </div>))}
    </div>
   </div>
  )
}

export default Categories;
