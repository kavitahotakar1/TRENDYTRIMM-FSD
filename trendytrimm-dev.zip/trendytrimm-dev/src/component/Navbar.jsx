import React, { useState, useEffect } from 'react';
import "../css/Navbar.css"
import RIMMINGS from "../assest/images/RIMMINGS.png";
import { Input, Button, Row, Col, Popover, Menu } from 'antd';
import { SearchOutlined, MenuOutlined } from '@ant-design/icons';
import { Link } from 'react-router-dom';
import { HeartOutlined, ShoppingCartOutlined } from '@ant-design/icons';
import { useDispatch,useSelector } from "react-redux";




const Navbar = () => {

    const dispatch = useDispatch();
    const cartItems = useSelector((state) => state.items);
    // console.log(cartItems?.length)
    

    const [showMenuIcon, setShowMenuIcon] = useState(false);
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isPopoverVisible, setIsPopoverVisible] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            const scrollPosition = window.scrollY;
            setShowMenuIcon(scrollPosition >= 1025);
        };
        window.addEventListener('scroll', handleScroll);

        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);


    const handleMenuClick = () => {
        setIsMenuOpen(!isMenuOpen);
    };



    const content = (
        <Menu mode="vertical" style={{width:"300px",border:"none",textAlign:"center"}}>
         <Menu.Item>
               <Link to='/' id='link' >  Home </Link>
                      </Menu.Item>
                         <Menu.Item>
                              <Link to='/categories' id='link'> Categories </Link>
                                  </Menu.Item>

                                     <Menu.Item>
                                        <Link to='/About' id='link'>  About                                                 </Link>
                                          </Menu.Item>

                                          <Menu.Item>
                                             <Link to='/Contact' id='link'> Contact </Link>
                                            </Menu.Item>
                                                 
                                        </Menu>          
    );

    return (
        <>
            <div className="navbar-section">
                <div className="navbar-container">

                    <div className='responsive-navbar'>

                        <Popover
                            content={content}
                            title={null}
                            trigger="click"
                            visible={isPopoverVisible}
                            onVisibleChange={(visible) => setIsPopoverVisible(visible)}
                            
                        >
                            <div className='menu-icon'>
                                <MenuOutlined style={{ fontSize: "25px", color: '#fff' }} />
                            </div>
                        </Popover>

                        

                        <div className='search-bar' style={{ display: "flex", justifyContent: "center" }}>
                            <Input
                                style={{ borderRadius: "20px", border: "1px solid #1e81b0" }}
                                placeholder="Search"
                                prefix={<SearchOutlined style={{}} />}
                                className="search-input"
                            />
                        </div>
                    </div>

                    <div className={`navbar-box ${isMenuOpen ? 'menu-open' : ''}`}>
                        <Row gutter={{ xs: 24, sm: 6, md: 12, lg: 32 }}>
                            <Col md={12}>
                                <div className='col-left'>
                                    <div className="logo">
                                        <img src={RIMMINGS} alt="logo"  />
                                    </div>
                                    <div className="navbar-items">
                                        <Menu mode="horizontal">
                                            <Menu.Item>
                                                <Link to='/' id='link'>  Home </Link>
                                            </Menu.Item>

                                            <Menu.Item>
                                                <Link to='/categories' id='link'> Categories </Link>
                                            </Menu.Item>

                                            <Menu.Item>
                                                <Link to='/About' id='link'>  About                                                 </Link>
                                            </Menu.Item>
                                               

                                            <Menu.Item>
                                                <Link to='/Contact' id='link'> Contact</Link>
                                            </Menu.Item>
                                                 
                                        </Menu>
                                    </div>
                                </div>

                            </Col>
                            <Col md={12} style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
                                <div className='col-right'>
                                    <div className='search-bar'>
                                        <Input
                                            style={{ borderRadius: "20px", border: "1px solid #1e81b0" }}
                                            placeholder="Search"
                                            prefix={<SearchOutlined style={{}} />}
                                            className="search-input"
                                        />
                                    </div>
                                    <div className='buttons'>
         <a href="/Loginform" className="btn btn-outline-dark ms-4">
         <i className="fa fa-sign-in"></i>Login 
        
         </a>
       
         <Link to="/Cart" className="btn btn-outline-dark ms-4" id='ccc'>
         <i className="fa fa-shopping-cart me-1"></i>  Cart <small>{cartItems?.length}</small>
         </Link>
       </div>                     
                                </div>

                            </Col>
                        </Row>

                    </div>
                 
                </div>
              
            </div>
        
        </>

    )
}

export default Navbar