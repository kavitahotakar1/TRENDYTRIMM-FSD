import React from "react";
import '../css/Forgot.css';
import back2 from "../assest/images/background4.jpg";
import { message } from "antd";

const Forgot = () => {
    const [messageApi, contextHolder] = message.useMessage();
        const key = 'updatable';
      
        const openMessage = () => {
          messageApi.open({
            key,
            type: 'loading',
            content: 'Loading...',
          });
          setTimeout(() => {
            messageApi.open({
              key,
              type: 'success',
              content: 'Updated Password',
              duration: 2,
            });
          }, 1000);
        };


    return(
        <div className="app">
            <div className="BMW">
          <img src={back2} alt='img' width={'100%'} height={'900px'}/></div>
                    <div className="wrapper">
                    <form action="">
                     <h1>Forgot Password</h1>
                     <div className="input-box">
                    <input type="text" placeholder='New password' required/>
                     </div>
                     <div className="input-box">
                    <input type="password" placeholder=" confirm Password" required/>
                    </div>

                    {contextHolder}
                    <button type="submit" onClick={openMessage}>Submit</button><br /><br />
                    <a id="Back" href="/Loginform">Back  </a>
                    
                    </form>

                    </div>

        </div>
      
                 
    )
}

export default Forgot;