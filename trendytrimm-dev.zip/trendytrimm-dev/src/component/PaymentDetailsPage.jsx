import React from 'react';
import '../css/PaymentDetailsPage.css';
import { message } from 'antd';
import { useState } from 'react';

const  PaymentDetailsPage= () => {
    const [messageApi, contextHolder] = message.useMessage();
  const key = 'updatable';

  const openMessage = () => {
    messageApi.open({
      key,
      type: 'loading',
      content: 'Loading...',
    });
    setTimeout(() => {
      messageApi.open({
        key,
        type: 'success',
        content: 'Ordered Successfully',
        duration: 2,
      });
    }, 1000);
  };

  const [formData, setFormData] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    // Add more fields as needed
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add form submission logic here, such as sending data to a server
    console.log('Form submitted:', formData);
  };

  return (
    <form className="payment-form" onSubmit={handleSubmit}>
      <label>
        Card Number:
        <input
          type="text"
          name="cardNumber"
          value={formData.cardNumber}
          onChange={handleChange}
          maxLength="16"
          required
        />
      </label>
      <label>
        Expiry Date:
        <input
          type="text"
          name="expiryDate"
          value={formData.expiryDate}
          onChange={handleChange}
          maxLength="4"
          placeholder="MM/YY"
          required
        />
      </label>
      <label>
        CVV:
        <input
          type="text"
          name="cvv"
          value={formData.cvv}
          onChange={handleChange}
          maxLength="3"
          required
        />
      </label>
      {contextHolder}
      <button  type="submit" onClick={openMessage}>Submit</button> <br />
      <a id="PPBB" href="/#">Back  </a>
    </form>
  );
};

export default PaymentDetailsPage;