import React from 'react';
import { Card, Row, Col } from 'antd';
import { StarOutlined, HeartOutlined, ShoppingCartOutlined } from '@ant-design/icons';
import productsData from "../data/Carddata";
import "../css/Product.css"


const Product = () => {
  return (
    <div>
         <div className="product">
                <div className="Product01">
                    
                <div className='details'>
                {
                    productsData?.map((product, index) => (
                       
                            <Row >
                            {
                                product?.map((product) => (
                                    <Col  className="Catspace">
                                        <div className="deta">
            <h3 id="del">{product.name}</h3>  
            <h3 id="del1">{product.price}<del id="DEL">{product.MRP}</del></h3>
            <span label="4" className=" Pro">
                     <span  font-size="16px" font-weight="demi" color="#ffffff" className="sc-eDvSVe laVOtN"><b>{product.star}</b> </span>
                    <div className="dkj">
                     <StarOutlined style={{ fontSize: '18px'}}/></div>
                  </span>
                  <div>
                  <span label="4" class="Free">
                     <span font-size="16px" >Free Delivery</span>
                   </span></div>
            </div>
            <br /><br />
            <div className="Slelectsize">
                   <h3 id="size">Select Size</h3>
                    <div class="sc-dPWrhe cfIFHf SizeSelectionstyled__SizeSelectorChipsStyled-sc-155vsje-2 dEkkqK">
                      <span class="sc-cUEOzv jlzegL">                         
                      <span  font-weight="demi" color="greyBase" >XS</span></span>
                         <span class="sc-cUEOzv jlzegL">
                           <span  font-weight="demi" color="greyBase">S</span></span>
                          <span class="sc-cUEOzv jlzegL">
                             <span  font-weight="demi" color="greyBase" >M</span></span>
                             <span class="sc-cUEOzv jlzegL">
                               <span  font-weight="demi" color="greyBase" >XL</span></span>
                               </div><br /><br /></div>
                              <div>
                               <div className="Proddetail">
                     <h3 id="Pp">Product Details</h3>
                     <div className="textt">
                     <h5 >Name : {product.name}</h5>
                     <h5>Fabric : Rayon</h5> 
                     <h5>Sleeve Length : Three-Quarter Sleeves</h5>
                     <h5>Combo of : Single</h5>
                    <h5>Sizes : XS, S, M, L</h5>
                     <h5>Country of Origin : India</h5>
                    <h5>More Information<br />--------------------</h5></div> 
                    
                    </div>
                               </div>
                                    </Col>
                                   
                                    
                                ))
                            }
                        </Row>
                        
                    ))}
            </div>
            </div>
            </div><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
            <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />

    </div>
  )
}

export default Product