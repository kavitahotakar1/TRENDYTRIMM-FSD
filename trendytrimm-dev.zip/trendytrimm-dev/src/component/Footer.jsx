import React from 'react'
import "../css/Footer.css";
import Link from 'antd/es/typography/Link';
import RIMMINGS from "../assest/images/RIMMINGS.png";
import { Col,Row } from 'antd';


const Footer = () => {
    return (

        
        <div className='footer-section'>
            <a href="#" id="navFooter" aria-label="Back to Top">

            <div className="NavFooter">
            <span className="navbartext">Back to Top</span>
            </div>
            </a> <br /> <br />
           
           <Row>
                <Col md={6}>
                <div className='Footer'>
                <div className="contact-us">
                   <img src={RIMMINGS} id='LG' alt='logo' />
                </div>
                </div>
                </Col>
                <Col md={6}>
                <div className="Footer1">
       <h3><b>Useful Links</b></h3>
       <ul>
                               <div className="menu-item">
                                    <Link href='/#'> Home</Link>
                                </div>

                                <div className="menu-item">
                                    <Link href='/categories'> Categories</Link>
                                </div>

                                <div className="menu-item">
                                    <Link href='/About '> About </Link>
                                </div>

                                <div className="menu-item">
                                    <Link href='/Contact'> Contact US</Link>
                                    </div>
                                      
                                    
       </ul>
   </div></Col>
   <Col md={6}>
   <div className="Footer1">
       <h3><b>Shop By</b></h3>
       <ul>
           <li>Women</li>
           <li>Men</li>
           <li>Kids</li>
           <li>Home</li>
       </ul>
   </div>
</Col>
<Col md={6}>
<div className="Footer1">
       <h3><b>Follow Us </b></h3>
       <ul>
           <li>Facebook</li>
           <li>Twitter</li>
           <li>Instagram</li>
           <li>Whatsapp</li>
       </ul>
   </div>
  
</Col>
</Row>
</div>

           
     
               
            
          
    )
}

export default Footer;