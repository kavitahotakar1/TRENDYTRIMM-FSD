import React from "react";
import { Carousel, Row, Col, Card } from "antd";
import '../css/Home.css';
import kurti from "../assest/images/k1.webp";
import a1 from "../assest/images/tunics.webp";
import sari from "../assest/images/s1.webp";
import lenga from "../assest/images/lenga1.webp";
import a2 from "../assest/images/a2.webp";
import Dress from "../assest/images/D1.webp";
import jump2 from "../assest/images/jump3.webp";
import winter from "../assest/images/w3.webp";
import salwar1 from "../assest/images/salear1.webp";
import slp from "../assest/images/slp2.webp";
import kurti2 from "../assest/images/kurti1.webp";
import a4 from "../assest/images/dress2.webp";
import slide2 from "../assest/images/slide2.png";
import slide5 from "../assest/images/slide5.webp";
import slide4 from "../assest/images/slide4.jpg";
import slid001 from "../assest/images/slide001.jpg";
import jacket from "../assest/images/Jacket.webp";
import E from "../assest/images/Eh2.webp";
import shirts from "../assest/images/shirts.webp";
import blazer from "../assest/images/blazer.webp";
import girl from "../assest/images/d2.webp";
import boy from "../assest/images/boy.webp";
import b1 from "../assest/images/b1.webp";
import winterkids from "../assest/images/wenter kids.webp";
import slid2 from "../assest/images/slid2.jpg";
import slid3 from "../assest/images/slid6.jpg";
import slid4 from "../assest/images/slid44.webp";
import slid5 from "../assest/images/slid5.jpg";




const {Meta} = Card;


const Home = () => {

  
  return (
    <div><br /><br /><br />
    
      
      <div className="slider">
        <Carousel autoplay  >

          <div>
            <img src={slid001} alt="slide 1" style={{ width: '100%' }} height="600px" />
          </div>

          <div>
            <img src={slide2} alt="slide 2" style={{ width: '100%' }} height="600px" />
          </div>

          <div>
            <img src={slide5} alt="slide 3" style={{ width: '100%' }} height="600px" />
          </div>
          <div>
            <img src={slide4} alt="slide 4" style={{ width: '100%' }} height="600px" />
          </div>

        </Carousel>
      </div>
      <div className="dd"><br /> <br />
        <Row className="space">
          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img id="IMG" src={kurti} alt="kurti"  height={'350px'}/>}
              >
                <Meta />
                <h2 id="KK">Kurtis</h2>
              </Card>
          </Col>

          <Col md={6}>
              <Card
              className="img-decor"
              hoverable 
              style={{width: 350}} 
              cover= {<img src={a1} alt="a1" height={'350px'}  />}
              >
                <Meta   />
                <h2 id="KK">Tops & Tunics</h2>
              </Card>
          </Col>
          
          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={sari} alt="sari"  height={'350px'}/>}
              >
                <Meta />
                <h2 id="KK">Sarees</h2>
              </Card>
          </Col>

          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={lenga} alt="lenga" height={'350px'} />}
              >
                <Meta />
                <h2 id="KK">Lehengas</h2>
              </Card>
          </Col></Row>

          <Row className="space">
          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={jacket} alt="jacket" height={'350px'} />}
              >
                <Meta  />
                <h2 id="KK">Jackets</h2>
              </Card>
          </Col>

          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={E} alt="E" height={'350px'} />}
              >
                <Meta />
                <h2 id="KK">Ethnic Wear</h2>
              </Card>
          </Col>

          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={shirts} alt="shirt" height={'350px'} />}
              >
                <Meta  />
                <h2 id="KK">Shirts</h2>
              </Card>
          </Col>

          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={blazer} alt="blazer" height={'350px'}/>}
              >
                <Meta  />
                <h2 id="KK">Blazers</h2>
              </Card>
          </Col>
          </Row>

          <Row className="space">

          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={a2} alt="a2" height={'350px'} />}
              >
                <Meta  />
                <h2 id="KK">Jeans</h2>
              </Card>
          </Col>

          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={Dress} alt="dress"  height={'350px'} />}
              >
                <Meta  />
                <h2 id="KK">Dresses</h2>
              </Card>
          </Col>

          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={jump2} alt="jump" height={'350px'} />}
              >
                <Meta  />
                <h2 id="KK">Jumpsuits</h2>
              </Card>
          </Col>
          
          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={winter} alt="winter" height={'350px'} />}
              >
                <Meta  />
                <h2 id="KK">winter Wears</h2>
              </Card>
          </Col></Row>
         

<div className="slider">
<Carousel autoplay  >

<div >
  <img src={slid2} alt="slide 1" style={{ width: '100%' }} height="600px" />
</div>

<div>
  <img src={slid3} alt="slide 2" style={{ width: '100%' }} height="600px" />
</div>

<div>
  <img src={slid4} alt="slide 3" style={{ width: '100%' }} height="600px" />
</div>
<div>
  <img src={slid5} alt="slide 4" style={{ width: '100%' }} height="600px" />
</div>

</Carousel>
</div><br />

          <Row className="space">
          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={salwar1} alt="salwar"  height={'350px'}/>}
              >
                <Meta  />
                <h2 id="KK">Salwar Suits</h2>
              </Card>
          </Col>

          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={slp} alt="slp"  height={'350px'}/>}
              >
                <Meta  />
                <h2 id="KK">Night Wears</h2>
              </Card>
          </Col>

          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={kurti2} alt="kurthi"  height={'350px'} />}
              >
                <Meta  />
                
                <h2 id="KK">Kurutis</h2>
              </Card>
          </Col>

          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={a4} alt="kurthi"  height={'350px'} />}
              >
                <Meta  />
                <h2 id="KK">Dressess</h2>
              </Card>
          </Col>  </Row>
         


          <Row className="space">
          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={girl} alt="kurthi" height={'350px'}/>}
              >
                <Meta  />
                <h2 id="KK">Girls Clothings</h2>
              </Card>
          </Col>

          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={boy} alt="body"  height={'350px'} />}
              >
                <Meta  />
                <h2 id="KK">Boys clothing</h2>
              </Card>
          </Col>

          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={b1} alt="img" height={'350px'} />}
              >
                <Meta  />
                <h2 id="KK">Baby Clothings</h2>
              </Card>
          </Col>

          <Col md={6}>
              <Card
              className="img-decor"
              hoverable
              style={{width: 350}}
              cover={<img src={winterkids} alt="kids"  height={'350px'} />}
              >
                <Meta  />
                <h2 id="KK">Winter Wears</h2>
              </Card>
          </Col>
        </Row>
      </div>
     
      
    </div>

  )

}
export default Home;