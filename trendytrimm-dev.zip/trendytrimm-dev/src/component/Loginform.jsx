import React from "react";
import '../css/Loginform.css';
import { FaUser } from "react-icons/fa";
import { FaLock } from "react-icons/fa";
import { message } from 'antd';
import back2 from "../assest/images/background4.jpg"




const LoginForm = () => {



  const [messageApi, contextHolder] = message.useMessage();
  const key = 'updatable';

  const openMessage = () => {
    messageApi.open({
      key,
      type: 'loading',
      content: 'Loading...',
    });
    setTimeout(() => {
      messageApi.open({
        key,
        type: 'success',
        content: 'Sucessfull Login!',
        duration: 2,
      });
    }, 1000);
  };
  return (
   <div className="app">
    <div className="BMW">
          <img src={back2} alt='img' width={'100%'} height={'900px'}/></div>

      <div className="wrapper">
        <form action="">
          <h1>Login </h1>




          <div className="input-box">
            <input type="text" className="UUS" placeholder='Username' required />
            <FaUser className="icon" />
          </div>
          <div className="input-box">
            <input type="password" placeholder="Password" required />
            <FaLock className="icon" />
          </div>



          <div className="remember-forgot">
            <label><input type="checkbox" />Remember me</label>
            <a href="/Forgot">Forgot password?</a>
          </div>

          {contextHolder}
          <button type="primary" 
          onClick={openMessage}> Login </button> <br /><br />
          <a id="Back" href="/#">Back  </a>


        </form>
        

      </div>
    </div>
  )
}
export default LoginForm;