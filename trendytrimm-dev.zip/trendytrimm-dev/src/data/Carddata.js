import a1 from "../assest/images/a1.webp";
import s1 from "../assest/images/sari.webp";
import T1 from "../assest/images/T1.webp";
import top1 from "../assest/images/top1.webp";
import salear1 from "../assest/images/salear1.webp";
import J1 from "../assest/images/J1.webp";
import jump2 from "../assest/images/jump2.webp";
import lenga from "../assest/images/lenga.webp";
import slp from "../assest/images/slp.webp";
import shirts from "../assest/images/shirts.webp";
import Hodi from "../assest/images/Hodi.webp";
import T2 from "../assest/images/T2.webp";
import jeans from "../assest/images/jeans.webp";
import Jack from "../assest/images/Jack.webp";
import menk from "../assest/images/menk.webp";
import girl from "../assest/images/girl.webp";
import boy from "../assest/images/boy.webp";
import Rompers from "../assest/images/Rompers.webp";
import b3 from "../assest/images/b3.webp";
import wenterkids from "../assest/images/wenter kids.webp";
import w2 from "../assest/images/w2.webp";
import jump5 from "../assest/images/jump5.webp"


const productsData =
[
        {
            id: 1,
            name: "Trendy Latest Women To...", 
            price: 300,
            category: "women's clothing",
            image: a1,
            quantity:1,
            mrp:350,
            star:4.1,
           
        },
        {
            id: 2,
            name: "Trendy Superior Sarres... ",
            price: 500,
            category: "women's clothing",
            image: s1,
            quantity:1,
            mrp:580,
            star:3.8,
        
        },
        {
            id: 3,
            name: "Classic Fabulor Women...",
            price: 300,
             category: "women's clothing",
            image:T1,
            quantity:1,
            mrp:580,
            star:4.1,
           
        },
        {
            id: 4,
            name: "Charvi Voguish Kurtis...",
            price: 300,
            category: "women's clothing",
            image: top1,
            quantity:1,
            mrp:320,
            star:3.8,
           
        },
        {
            id: 5,
            name: "Alisha Petite Salwar Suit...",
            price: 550,
            category: "women's clothing",
            image:salear1,
            quantity:1,
            mrp:600,
            star:4.2,
           
        },
        {
            id: 6,
            name: "Pretty Feminine Women...",
            price: 450,
            category: "women's clothing",
            image:J1,
            quantity:1,
            mrp:580,
            star:3.9,
    
            
        },
        {
            id: 7,
            name: "Classic Designer Wome...",
            price: 550,
            category: "women's clothing",
            image: jump2,
            quantity:1,
            mrp:650,
            star:4.1,
            
        },
        {
            id: 8,
            name: "Classic Designer Wome...",
            price: 1000,
            category: "women's clothing",
            image: lenga,
            quantity:1,
            mrp:1500,
            star:3.9,
           
        },
        {
            id: 9,
            name: "Classic Designer Wome...",
            price: 350,
            category: "women's clothing",
            image: slp,
            quantity:1,
            mrp:400,
            star:4.2,
           
        },
        {
            id: 10,
            name: "Fancy Fashinable Men...",
            price: 499,
            category1: "men's clothing",
            image: shirts,
            quantity:1,
            mrp:500,
            star:4.3,
           
            
        },
        {
            id: 11,
            name: "Urbane Fabulous Men S...",
            price: 800,
            category1: "men's clothing",
            image:Hodi,
            quantity:1,
            mrp:1000,
            star:4.1,
            
        },
        {
            id: 12,
            name: "Fashinable Men Ethnic...",
            price: 550,
            category1: "men's clothing",
            image: T2,
            quantity:1,
            mrp:599,
            star:4.2,
            

            

            
        },
        {
            id: 13,
           name: "Ravishining Fashinable Men...",
            price: 559,
           category1: "men's clothing",
            image: jeans,
            quantity:1,
            mrp:700,
            star:3.6,
          
        },
        {
            id: 14,
            name: "Stylish Partywear Men J...",
            price: 999,
            category1: "men's clothing",
            image: Jack,
            quantity:1,
            mrp:2500,
            star:3.9,
            
        },
        {
            id: 15,
            name: "Urbane Men Kurtas...",
            price: 600,
            category1: "men's clothing",
            image: menk,
            quantity:1,
            mrp:699,
            star:4.1,
           
        },
        {
            id: 16,
            name: "Cute Eligant Girls Fork...",
            price: 399,
            category2: "kid's clothing",
            image: girl,
            quantity:1,
            mrp:499,
            star:3.6,
           
        },
        {
            id: 17,
            name: "Cute Fancy Girls Top & B...",
            price: 500,
            category2: "kid's clothing",
            image:boy,
            quantity:1,
            mrp:599,
            star:4.2,
          
        },
        {
            id: 18,
            name: "Tinkle Stylish Boys Ones...",
            price: 399,
            category2: "kid's clothing",
            image:Rompers,
            quantity:1,
            mrp:400,
            star:3.8,
        
        },
        {
            id: 19,
            name: "Agile Stylus girls Fork ...",
            price: 399,
           category2: "kid's clothing",
            image: b3,
            quantity:1,
            mrp:500,
            star:4.1,
        
        },
        {
            id: 20,
            name: "Tinkle Stylish Boys Ones...",
            price: 599,
            category2: "kid's clothing",
            image: wenterkids,
            quantity:1,
            mrp:650,
            star:4.3,
           
        },

        {
            id: 21,
            name: "Classic Designer Wome...",
            price: 400,
            category2: "kid's clothing",
            image: jump5,
            quantity:1,
            mrp:500,
            star:4.3,
           
        },

        {
            id: 22,
            name: "Modern Faancy Boys Top...",
            price: 300,
            category2: "kid's clothing",
            image:w2,
            quantity:1,
            mrp:350,
            star:3.8,
         
        }
    
]


  export default productsData;