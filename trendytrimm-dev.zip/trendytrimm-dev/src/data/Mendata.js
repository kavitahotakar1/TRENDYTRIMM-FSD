import shirts from '../assest/images/shirts.webp';
import Hodi from '../assest/images/Hodi.webp';
import T2 from '../assest/images/T2.webp';
import jeans from '../assest/images/jeans.webp';
import Jack from '../assest/images/Jack.webp';
import menk from '../assest/images/menk.webp';

const Mendata = 

[

{
    id: 10,
    name: "Fancy Fashinable Men...",
    price: 499,
    category1: "men's clothing",
    image: shirts,
    quantity:1,
    mrp:500,
    star:4.1
   
    
},
{
    id: 11,
    name: "Urbane Fabulous Men S...",
    price: 800,
    category1: "men's clothing",
    image:Hodi,
    quantity:1,
    mrp:1000,
    star:3.6
    
},
{
    id: 12,
    name: "Fashinable Men Ethnic...",
    price: 550,
    category1: "men's clothing",
    image: T2,
    quantity:1,
    mrp:599,
    star:4.2
    

    

    
},
{
    id: 13,
   name: "Ravishining Fashinable Men...",
    price: 559,
   category1: "men's clothing",
    image: jeans,
    quantity:1,
    mrp:700,
    star:4.1
  
},
{
    id: 14,
    name: "Stylish Partywear Men J...",
    price: 999,
    category1: "men's clothing",
    image: Jack,
    quantity:1,
    mrp:2500,
    star:3.2
    
},
{
    id: 15,
    name: "Urbane Men Kurtas...",
    price: 600,
    category1: "men's clothing",
    image: menk,
    quantity:1,
    mrp:699,
    star:3.8
   
},


  

]

export default Mendata;