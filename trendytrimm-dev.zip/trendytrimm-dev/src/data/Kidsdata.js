import girl from '../assest/images/girl.webp';
import boy from '../assest/images/boy.webp';
import Rompers from '../assest/images/Rompers.webp';
import b3 from '../assest/images/b3.webp';
import wenterkids from '../assest/images/wenter kids.webp'
import w2 from '../assest/images/w2.webp';
import jump5 from "../assest/images/jump5.webp"
const Kidsadata = 
    [
        {
            id: 16,
            name: "Cute Eligant Girls Fork...",
            price: 399,
            category2: "kid's clothing",
            image: girl,
            quantity:1,
            mrp:499,
            star:4.1,
           
        },
        {
            id: 17,
            name: "Modern Faancy Boys Top...",
            price: 500,
            category2: "kid's clothing",
            image:boy,
            quantity:1,
            mrp:599,
            star:3.6,
          
        },
        {
            id: 18,
            name: "Tinkle Stylish Boys Ones...",
            price: 399,
            category2: "kid's clothing",
            image:Rompers,
            quantity:1,
            mrp:400,
            star:4.1,
        
        },
        {
            id: 19,
            name: "Agile Stylus girls Fork ...",
            price: 399,
           category2: "kid's clothing",
            image: b3,
            quantity:1,
            mrp:500,
            star:3.9,
        
        },
        {
            id: 20,
            name: "Tinkle Stylish Boys Ones...",
            price: 599,
            category2: "kid's clothing",
            image: wenterkids,
            quantity:1,
            mrp:650,
            star:4.1,
           
        },
        {
            id: 21,
            name: "Modern Faancy Boys Top...",
            price: 300,
            category2: "kid's clothing",
            image:w2,
            quantity:1,
            mrp:350,
            star:4.2,
         
        },
        {
            id: 22,
            name: "Classic Designer Wome...",
            price: 400,
            category2: "kid's clothing",
            image: jump5,
            quantity:1,
            mrp:500,
            star:4.3,
           
        },

    
]

export default Kidsadata;