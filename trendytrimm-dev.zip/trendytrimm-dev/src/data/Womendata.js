import Women from '../css/Women.css';
import a1 from '../assest/images/a1.webp';
import s1 from '../assest/images/s1.webp';
import T1 from '../assest/images/T1.webp';
import top1 from '../assest/images/top1.webp';
import salear1 from '../assest/images/salear1.webp';
import J1 from '../assest/images/J1.webp';
import jump2 from '../assest/images/jump2.webp';
import lenga from '../assest/images/lenga.webp';
import slp from '../assest/images/slp.webp';
import T5 from '../assest/images/T5.webp';


const Womendata =
[
    
        {
            id: 1,
            name: "Trendy Latest Women To...", 
            price: 300,
            category: "women's clothing",
            image: a1,
            quantity:1,
            MRP:350,
            star:4.2
           
        },
        {
            id: 2,
            name: "Trendy Superior Sarres... ",
            price: 500,
            category: "women's clothing",
            image: s1,
            quantity:1,
            MRP:580,
            star:4.1
        
        },
        {
            id: 3,
            name: "Classic Fabulor Women...",
            price: 300,
             category: "women's clothing",
            image:T1,
            quantity:1,
            MRP:580,
            star:3.5
           
        },
        {
            id: 4,
            name: "Charvi Voguish Kurtis...",
            price: 300,
            category: "women's clothing",
            image: top1,
            quantity:1,
            MRP:320,
            star:3.2
           
        },
        {
            id: 5,
            name: "Alisha Petite Salwar Suit...",
            price: 550,
            category: "women's clothing",
            image:salear1,
            quantity:1,
            MRP:600,
            star:3.6
           
        },
        {
            id: 6,
            name: "Pretty Feminine Women...",
            price: 450,
            category: "women's clothing",
            image:J1,
            quantity:1,
            MRP:580,
            star:4.1
    
            
        },
        {
            id: 7,
            name: "Classic Designer Wome...",
            price: 550,
            category: "women's clothing",
            image: jump2,
            quantity:1,
            MRP:650,
            star:4.2
            
        },
        {
            id: 8,
            name: "Classic Designer Wome...",
            price: 1000,
            category: "women's clothing",
            image: lenga,
            quantity:1,
            MRP:1500,
            star:3.2
           
        },
        {
            id: 9,
            name: "Classic Designer Wome...",
            price: 350,
            category: "women's clothing",
            image: slp,
            quantity:1,
            MRP:400,
            star:4.1
           
        },
        {
            id: 3,
            name: "Classic Fabulor Women...",
            price: 300,
             category: "women's clothing",
            image:T5,
            quantity:1,
            MRP:580,
            star:3.5
           
        },
    
]

export default Womendata;