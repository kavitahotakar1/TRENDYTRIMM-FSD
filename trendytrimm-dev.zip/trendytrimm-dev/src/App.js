import { Provider } from 'react-redux';
import './App.css';

import AppRoute from './route/index';
import toast,{Toaster} from 'react-hot-toast';

function App() {
  return (
  
    <div>
      <AppRoute />
      <Toaster/>
    </div>
   
  );
}

export default App;



